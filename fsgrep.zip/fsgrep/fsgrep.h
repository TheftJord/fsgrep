/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   fsgrep.h
 * Author: student
 *
 * Created on February 25, 2024, 9:43 PM
 */

#ifndef FSGREP_H
#define FSGREP_H

#ifdef __cplusplus
extern "C" {
#endif

void fsgrep(const char* keyword, const char* file);


#ifdef __cplusplus
}
#endif

#endif /* FSGREP_H */

